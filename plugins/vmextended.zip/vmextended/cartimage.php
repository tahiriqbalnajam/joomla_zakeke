<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;

class PlgVMExtendedCartimage extends CMSPlugin
{
    protected $autoloadLanguage = true;

    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        if (!class_exists('VmConfig')) {
            require_once JPATH_ADMINISTRATOR . '/components/com_virtuemart/helpers/config.php';
        }
        VmConfig::loadConfig();
    }

    public function plgVmOnViewCart($product, &$productrow, &$customfields)
    {
        // Check if product has custom data
        if (isset($product->customProductData)) {
            foreach ($product->customProductData as $field) {
                if (isset($field['designid'])) {
                    // Replace image URL with custom preview URL
                    $newImageUrl = $this->getCustomImageUrl($field['designid']);
                    if ($newImageUrl) {
                        $product->product_thumb_image = $newImageUrl;
                        break;
                    }
                }
            }
        }
        return true;
    }

    private function getCustomImageUrl($designId)
    {
        // Replace with your logic to get image URL based on design ID
        // Example:
        return 'https://your-domain.com/designs/' . $designId . '/preview.jpg';
    }
}