<?php
namespace Zakeke\Component\Tasks\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

class ConfigController extends FormController
{
    protected $text_prefix = 'COM_ZAKEKE';
}